<?php


use Drupal\Core\Routing\RouteMatchInterface;

function bm_core_theme(): array {
  return [
    'bm_theme_switcher' => [
      'render element' => 'elements',
    ],
  ];
}

/**
 * Implements hook_preprocess_bm_theme_switcher().
 */
function bm_core_preprocess_bm_theme_switcher(array &$variables): void {
  // Attach library to ensure CSS/JS are present wherever the theme switcher is rendered.
  $variables['#attached']['library'][] = 'bm_core/theme_switcher';
}



function bm_core_help($route_name, RouteMatchInterface $route_match) {
  if ($route_name === 'help.page.bm_core') {
    return '<p>BM Core provides reusable UI utilities.
            This module includes a theme switcher component allowing users to toggle Light, Dark, or System color modes.
            </p>
            <p>
            See <a href="/admin/config/bm-core/theme-switcher-demo"> ThemeSwitcherDemoForm</a> for more example.
            </p>';
  }
}
