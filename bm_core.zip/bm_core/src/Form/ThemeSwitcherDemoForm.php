<?php

declare(strict_types=1);

namespace Drupal\bm_core\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Demo form that renders the bm_theme_switcher component.
 */
final class ThemeSwitcherDemoForm extends FormBase {

  public function getFormId(): string {
    return 'bm_core_theme_switcher_demo_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state): array {
    // Ensure the library is present.
    $form['#attached']['library'][] = 'bm_core/theme_switcher';

    $form['description'] = [
      '#markup' => $this->t('<p>Use the buttons below to switch between light, dark, and system themes.</p>'),
    ];

    // Render the Twig theme hook explicitly.
    $form['switcher'] = [
      '#theme' => 'bm_theme_switcher',
    ];

    return $form;
  }

  public function submitForm(array &$form, FormStateInterface $form_state): void {
    // No submit handling needed; purely a demo.
  }

}
